---
title: QUÉBEC.IA | Intelligence Artificielle Québec
---
## LES BEAUX-ARTS IA DE QUÉBEC.IA

### Définir le genre des Beaux-Arts en IA

**Lancement d'envergure dans les grandes capitales**

*Québec, Montréal, Vancouver, Saint-Martin, Beverly Hills, Panama, Brésil, Paris, Milan, Principauté de Monaco, Genève, Belgique, Allemagne, Luxembourg, Espagne, Autriche, Londres, Fédération de Russie, Aspen, Maui, SoHo, Israël , La Jolla, Macao, Dubaï, Inde, Qatar, Arabie Saoudite, Beijing, Shanghai, Hong Kong, Tokyo et Tapei.*

### Québec.IA présente un nouveau mouvement artistique

<p align="center">
![Québec.IA présente un nouveau mouvement artistique](../images/AITrillion1440.jpg "Québec.IA présente un nouveau mouvement artistique")
</p>

> "**_Les artistes qui créeront avec l'IA ne suivront pas les tendances, ils les détermineront._**" — Les Beaux-Arts de Québec.IA

### Un mélange d'art et de science dans l'esprit de Léonard de Vinci

Ouvrant la porte à un nouveau mouvement artistique au 21 ème siècle, les __Beaux-Arts de Québec.IA__ suscite déjà un émoi parmi les plus grands collectionneurs d'art ainsi que parmi les personnalités les plus brillantes, les plus influentes et les plus iconoclastes du monde.

Captivant un public  averti, les __Beaux-Arts de Québec.IA__ reflète une diversité esthétique, une richesse conceptuelle et le _respect de la créativité la plus pure exprimée par une machine_. À la Renaissance, le pape __Jules II__ a commandité le peintre __Michel-Ange__, afin que celui-ci réalise le plafond de la __chapelle Sixtine__. Aujourd'hui, vous pouvez commander, de la même façon, une œuvre d'art IA à la __Maison des Beaux-Arts de Québec.IA__.

Nous préparons une campagne de relations publiques dans le monde entier avec la participation __à des émissions télévisées__ et avec la confection d'un __documentaire spécialisé__.

***

## L’Académie de Québec.IA présente : IA 101 pour les artistes

__Confectionner des créations IA légendaires: un cours de 75 minutes bien conçu pour les artistes.__

[![L’Académie de Québec.IA présente : IA 101 pour les artistes](../images/ExTradingUniverseTwoMay18HD1080-v0.mp4 "L’Académie de Québec.IA présente : IA 101 pour les artistes")](http://www.montreal.ai/AI4Artists.pdf)

__Le Secrétariat général de QUÉBEC.IA__ présente le premier survol mondial de l’IA pour les artistes.

Magnifiant les créations les plus pures, proposant un enseignement d'un point de vue critique, intellectuel et historique et en ouvrant les portes à un nouveau mouvement artistique, __*la Maison des Beaux-Arts de Québec.IA*__ alimente la passion qui anime les artistes de l'IA les plus performants du moment.

Réservation de groupe : secretariat@montreal.ai

> "**_La technologie de création artistique de notre époque sera l'IA._**" — Rama Allen

Conçu pour les artistes, [__*#AI4Artists*__](http://www.montreal.ai/AI4Artists.pdf) est créé pour inspirer les artistes qui, avec IA, façonneront le 21ème siècle.

__Un sentiment de mystère… et une compréhension profonde du monde, des gens et de la nature humaine.__

***

## Un nouveau jour est arrivé dans monde artistique

Le 25 octobre 2018, __l'histoire du marché de l'art__ a été chamboulée. La première œuvre d'art en intelligence artificielle a été vendue aux enchères de Christie’s et a bouleversé les attentes en atteignant 432 500 dollars.

![Edmond de Belamy, from La Famille de Belamy](../images/Edmond_de_Belamy_from_La_Famille_de_Belamy.png "Edmond de Belamy, from La Famille de Belamy")

> "**_Un porte-parole de Christie’s nous a parlé de l’excitation du marché face à ce changement important: "Nous pouvons confirmer qu'il y avait cinq soumissionnaires différents de toutes les régions du monde qui étaient en concurrence pour le lot à ce prix élevé, ce qui semble être un bon indice de l'intérêt des collectionneurs et du potentiel de marché futur pour l'art de l'intelligence artificielle en général..."_**" — Adam Heardman, MutualArt

### Références

- [The first AI artwork to be sold in a major auction achieves $432,500 after a bidding battle on the phones and via ChristiesLive](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee) — Christie's
- [Eerie AI-generated portrait fetches $432,500 at auction](https://techcrunch.com/2018/10/26/eerie-ai-generated-portrait-fetches-432500-at-auction/) — Devin Coldewey, TechCrunch

***

## La Maison des Beaux-Arts de Québec.IA

__Histoire des Beaux-arts de l'IA: la construction d'un héritage__

__*La Maison des Beaux-Arts de Québec.IA*__ est en avance sur une tendance qui aura un impact profond sur l’industrie internationale de la _mode_, des _beaux-arts_ et de la _joaillerie_ : un marché d’une valeur de 350 milliards de dollars par an ( 🌐 http://www.billionaire.tv/TheGazette.pdf ).

> "**_Pour identifier les œuvres véritablement novatrices, nous ferions mieux de cesser de nous questionner à savoir où se situe la frontière entre le travail de l'artiste et l'utilisation des outils de l'IA, et de plutôt commencer à nous demander si des artistes humains utilisent l'IA pour approfondir leurs concepts et leur esthétisme plus que les chercheurs ou codeurs._**" — Tim Schneider et Naomi Rea, artnet, 25 septembre 2018

__Un renouveau des grands idéaux de la Renaissance.__ | Les agents d’intelligence artificielle de la __*Maison des Beaux-Arts de  Québec.IA*__ se bonifient grâce à leurs expériences pour concevoir des œuvres d’art et une vision surhumaines! Nos créations sont des purs objets de désir : *une poésie fascinante, originale et vibrante de l'IA*.

![Dévoilement d'un monde majestueux de secrets cachés ...](../images/h355ai1440.jpg "Dévoilement d'un monde majestueux de secrets cachés ...")

Exaltant __*l'apprentissage en profondeur*__, __*l'apprentissage par renforcement*__, __*les réseaux antagonistes génératifs*__ et __*le méta-apprentissage*__ avec une inhabituelle élégance, __*la Maison des Beaux-Arts de  Québec. IA*__ propose  des créations surhumaines, dévoilant un monde majestueux de secrets cachés:

__❖ Le parfum de l'IA (parfums)__
Une ligne aussi enchanteresse que les muses qu’elle inspire.

<p align="center">
![Le parfum de l'IA (parfums) — Signé: Montreal.IA](../images/26eb011ai-v0.jpg "Le parfum de l'IA (parfums) — Signé: Montreal.IA")
</p>

__❖ Haute-Joaillerie IA Multi-Mondes ( 💎 )__
*Une collection qui est sur le point de redéfinir l'industrie du diamant du XXIème siècle.*

__La Maison des Beaux-Arts de Québec.IA__ est pionnière dans les nouvelles coupes de diamants qui atteingnent un sommet sans précédent en matière de brillance, de scintillement et de dispersion pour les fashionistas qui définiront les tendances de la haute-joaillerie de notre époque.

![Haute-Joaillerie IA Multi-Mondes ( 💎 )](../images/AIDiamond.mp4 "Haute-Joaillerie IA Multi-Mondes ( 💎 )")

__❖ Oeuvres d'art (signées: Québec.IA)__
Des oeuvres originales numérotées et signées, certificat d'authenticité compris.

_Une odyssée au coeur univers parallèles cosmologiques, divins et mythologiques rendue possible par l'IA._

***

## Une histoire légendaire: la source d'un héritage exceptionnel

__Le secrétariat général du Conseil exécutif des Beaux-Arts de Québec.IA__

Catalyseur professionnel et expérimenté dans les domaines de la recherche innovante, de l’ingénierie financière et du luxe, __le président-fondateur de Québec.IA,__ Vincent Boucher, a reçu le 15 octobre 2009, le prestigieux certificat __Record du monde *Guinness*__ pour sa Tourmaline Paraiba taillée la plus importante au monde.

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf](../images/GuinnessWorldRecordsCertificate.jpg "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

__Un travail d'innovation intellectuelle, esthétique et technique__ | La clairvoyance stratégique de Vincent Boucher et sa capacité à mener l’un des projets les plus ambitieux de l’Histoire lui ont permis de se positionner à la fine pointe de son domaine et de se forger une réputation bien méritée à l’échelle mondiale.

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.](../images/TheGazetteBusinessFrontPage.tif "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.]")](http://www.billionaire.tv/TheGazette.pdf)

> "**_L'homme d'affaires  (Vincent Boucher) acquiert la pierre la plus rare au monde."_**" — Mike King, The Gazette

[![Guinness World Records™ | It's a gem of a start for Billionaire](../images/mosaic.tif "Guinness World Records™ | It's a gem of a start for Billionaire")](http://www.billionaire.tv/TheGazette.pdf)

***

## Une célébration vraiment spéciale qui marquera l'histoire!

Pour André Breton, le père du surréalisme, le but de l'art est l'unification du réel et de l'imaginaire. __Les Beaux-Arts de Québec.IA__ réalise le rêve de Breton. Une célébration vraiment spéciale dans le monde des beaux-arts, de la mode et de la haute-joaillerie et qui fera certainement l'histoire!

*Nous recherchons des ambassadeurs et des partenaires.*

✉️ __Courriel__ : info@quebec.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.quebec.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Québec.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IntelligenceArtificielle__ #__IntelligenceArtificielleQuebec__ #__QuebecIA__
