---
title: QUÉBEC.IA | Intelligence Artificielle Québec
---
## __LES BEAUX-ARTS DE QUÉBEC.IA__

### __*Une nouvelle ère dans l'industrie de l'art, de la mode et de la joaillerie*__

__Lancement d'envergure dans les grandes capitales:__ *Québec, Montréal, Vancouver, Saint-Martin, Beverly Hills, Panama, Brésil, Paris, Milan, Principauté de Monaco, Genève, Belgique, Allemagne, Luxembourg, Espagne, Autriche, Londres, Fédération de Russie, Aspen, Maui, La Jolla, Macao, Dubaï, Qatar, Shanghai, Hong Kong, Tokyo et Tapei.*

### __QUÉBEC.IA présente un nouveau mouvement artistique__

![Les Beaux-Arts de QUÉBEC.IA: une nouvelle ère dans l'industrie de l'art, de la mode et de la joaillerie](../images/AITrillion1440.jpg "Les Beaux-Arts de QUÉBEC.IA: une nouvelle ère dans l'industrie de l'art, de la mode et de la joaillerie")

### Un mélange d'art et de science dans l'esprit de Léonard de Vinci

La __*Maison des Beaux-Arts de QUÉBEC.IA*__ suscite déjà un émoi parmi les plus grands collectionneurs d'art ainsi que parmi les personnalités les plus brillantes, les plus influentes et les plus iconoclastes du monde.

> "**_Les artistes qui créeront avec l'IA ne suivront pas les tendances, ils les détermineront._**" — La Maison des Beaux-Arts de QUÉBEC.IA

Captivant un public averti, les __Beaux-Arts de QUÉBEC.IA__ reflète une diversité esthétique, une richesse conceptuelle et le _respect de la créativité la plus pure exprimée par une machine_. Nous préparons une campagne de relations publiques dans le monde entier avec la participation à des émissions télévisées.

La __*Maison des Beaux-Arts de QUÉBEC.IA*__ est en avance sur une tendance qui aura un impact profond sur l’industrie de la _mode_, des _beaux-arts_ et de la _joaillerie_ : un marché d’une valeur de 350 milliards de dollars par an.

***

## __Un nouveau jour est arrivé dans monde artistique__

Le 25 octobre 2018, __l'histoire du marché de l'art__ a été chamboulée. La première œuvre d'art en intelligence artificielle a été vendue aux enchères de Christie’s et a bouleversé les attentes en atteignant 432 500 dollars.

![Edmond de Belamy, de La Famille de Belamy](../images/Edmond_de_Belamy_from_La_Famille_de_Belamy.png "Edmond de Belamy, de La Famille de Belamy")

### Références

- [The first AI artwork to be sold in a major auction achieves $432,500 after a bidding battle on the phones and via ChristiesLive](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee) — Christie's
- [Eerie AI-generated portrait fetches $432,500 at auction](https://techcrunch.com/2018/10/26/eerie-ai-generated-portrait-fetches-432500-at-auction/) — Devin Coldewey, TechCrunch

> "**_Un porte-parole de Christie’s nous a parlé de l’excitation du marché face à ce changement important: "Nous pouvons confirmer qu'il y avait cinq soumissionnaires différents de toutes les régions du monde qui étaient en concurrence pour le lot à ce prix élevé, ce qui semble être un bon indice de l'intérêt des collectionneurs et du potentiel de marché futur pour l'art de l'intelligence artificielle en général..."_**" — Adam Heardman, MutualArt

***

## __La Maison des Beaux-Arts de QUÉBEC.IA__

__La construction d'un héritage d'exception__

__Un renouveau des grands idéaux de la Renaissance.__ — Les agents d’intelligence artificielle de la __*Maison des Beaux-Arts de QUÉBEC.IA*__ se bonifient grâce à leurs expériences pour concevoir des œuvres d’art et une vision surhumaines! Nos créations sont des purs objets de désir : *une poésie fascinante, originale et vibrante*.

![La Maison des Beaux-Arts de QUÉBEC.IA: Dévoilement d'un monde majestueux de secrets cachés ...](../images/h355ai1440.jpg "La Maison des Beaux-Arts de QUÉBEC.IA: Dévoilement d'un monde majestueux de secrets cachés ...")

Exaltant __*l'apprentissage profond*__, __*l'apprentissage par renforcement*__, __*les réseaux antagonistes génératifs*__ et __*le méta-apprentissage*__ avec une inhabituelle élégance, la __*Maison des Beaux-Arts de QUÉBEC.IA*__ propose  des créations surhumaines, dévoilant un monde majestueux de secrets cachés:

__❖ Haute-Joaillerie IA Multi-Mondes ( 💎 )__
*Une collection qui est sur le point de redéfinir l'industrie du diamant du XXIème siècle.*

![Haute-Joaillerie IA Multi-Mondes ( 💎 )](../images/AIDiamond.mp4 "Haute-Joaillerie IA Multi-Mondes ( 💎 )")

La __Maison des Beaux-Arts de QUÉBEC.IA__ est pionnière dans les nouvelles coupes de diamants qui atteingnent un sommet sans précédent en matière de brillance, de scintillement et de dispersion pour les fashionistas qui définiront les tendances de la haute-joaillerie de notre époque.

__❖ Oeuvres d'art (signées: QUÉBEC.IA)__
Des oeuvres originales numérotées et signées, certificat d'authenticité compris.

_Une odyssée au coeur d'univers parallèles cosmologiques, divins et mythologiques rendue possible par l'IA._

__❖ Le parfum de l'IA (parfums)__
Une ligne aussi enchanteresse que les muses qu’elle inspire.

<p align="center">
![Le parfum de l'IA (parfums) — Signé: QUÉBEC.IA](../images/26eb011ai-v0.jpg "Le parfum de l'IA (parfums) — Signé: QUÉBEC.IA")
</p>

***

## __Une histoire légendaire: la source d'un héritage exceptionnel__

__Le Conseil Exécutif des Beaux-Arts de QUÉBEC.IA__

Catalyseur professionnel et expérimenté dans les domaines de la recherche innovante, de l’ingénierie financière et du luxe, __le président-fondateur de QUÉBEC.IA,__ Vincent Boucher, a reçu le 15 octobre 2009, le prestigieux certificat __Record du monde *Guinness*__ pour sa Tourmaline Paraiba taillée la plus importante au monde.

[![Le président de QUÉBEC.IA, Vincent Boucher, détient un record du monde Guinness dans l'industrie des beaux-arts et de la haute joaillerie: http://www.billionaire.tv/TheGazette.pdf](../images/GuinnessWorldRecordsCertificate.jpg "Le président de QUÉBEC.IA, Vincent Boucher, détient un record du monde Guinness dans l'industrie des beaux-arts et de la haute joaillerie: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

__Un travail d'innovation intellectuelle, esthétique et technique__ | La clairvoyance stratégique de Vincent Boucher et sa capacité à mener l’un des projets les plus ambitieux de l’Histoire lui ont permis de se positionner à la fine pointe de son domaine et de se forger une réputation bien méritée à l’échelle mondiale.

[![Le président de QUÉBEC.IA, Vincent Boucher, détient un record du monde Guinness dans l'industrie des beaux-arts et de la haute joaillerie: http://www.billionaire.tv/TheGazette.pdf](../images/TheGazetteBusinessFrontPage.tif "Le président de QUÉBEC.IA, Vincent Boucher, détient un record du monde Guinness dans l'industrie des beaux-arts et de la haute joaillerie: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

> "**_L'homme d'affaires  (Vincent Boucher) acquiert la pierre la plus rare au monde._**" — Mike King, The Gazette

[![Guinness World Records™ | It's a gem of a start for Billionaire](../images/mosaic.tif "Guinness World Records™ | It's a gem of a start for Billionaire")](http://www.billionaire.tv/TheGazette.pdf)

Une compréhension profonde du monde, des gens et de la nature humaine.

***

## __L'Orchestre de QUÉBEC.IA: *CONCERT IA*__

### Des symphonies pionnières légendaires

[![L'Orchestre de QUÉBEC.IA: Des symphonies pionnières légendaires](../images/AIConcertv2.jpg "L'Orchestre de QUÉBEC.IA: Des symphonies pionnières légendaires")](https://aiconcert.eventbrite.ca)

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## __L’Académie de QUÉBEC.IA: *IA 101 pour les artistes*__

__L’Académie de QUÉBEC.IA__ présente le premier survol mondial de l’IA pour les artistes.

*Confectionner des créations IA légendaires.*

> "**_Pour identifier les œuvres véritablement novatrices, nous ferions mieux de cesser de nous questionner à savoir où se situe la frontière entre le travail de l'artiste et l'utilisation des outils de l'IA, et de plutôt commencer à nous demander si des artistes humains utilisent l'IA pour approfondir leurs concepts et leur esthétisme plus que les chercheurs ou codeurs._**" — Tim Schneider et Naomi Rea, Artnet

Réservation de groupe : secretariat@montreal.ai

Conçu pour les artistes, [__*#AI4Artists*__](http://www.montreal.ai/AI4Artists.pdf) est créé pour inspirer les artistes qui, avec IA, façonneront le 21ème siècle.

***

## __Une célébration vraiment spéciale qui marquera l'histoire!__

Pour André Breton, le père du surréalisme, le but de l'art est l'unification du réel et de l'imaginaire. La __*Maison des Beaux-Arts de QUÉBEC.IA*__ réalise le rêve de Breton. Une célébration vraiment spéciale dans le monde des beaux-arts, de la mode et de la haute-joaillerie et qui fera certainement l'histoire!

À la Renaissance, le pape __Jules II__ a commandité __Michel-Ange__, afin que celui-ci réalise le plafond de la __chapelle Sixtine__. Aujourd'hui, vous pouvez commander une œuvre à la __*Maison des Beaux-Arts de QUÉBEC.IA*__.

> "**_La technologie de création artistique de notre époque sera l'IA._**" — Rama Allen

Magnifiant les créations les plus pures, proposant un enseignement d'un point de vue critique, intellectuel et historique et ouvrant les portes à un nouveau mouvement artistique, la __*Maison des Beaux-Arts de QUÉBEC.IA*__ alimente la passion qui anime les artistes de l'IA.

*Nous recherchons des ambassadeurs et des partenaires.*

✉️ __Courriel :__ info@quebec.ai
📞 __Téléphone :__ +1.514.829.8269
🌐 __Site web :__ http://www.quebec.ai/
📝 __LinkedIn :__ https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Québec.IA :__ 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif exclusivement*

#__IntelligenceArtificielleQuebec__ #__QuebecIA__
