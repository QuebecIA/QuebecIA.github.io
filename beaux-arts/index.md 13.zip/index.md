---
title: QUÉBEC.IA | Intelligence Artificielle Québec
---
## LES BEAUX-ARTS IA DE QUÉBEC.IA (version préliminaire)

__Redéfinition de l'histoire de l'art | Lancement d'envergure dans les grandes capitales__

*Québec, Montréal, Vancouver, Saint-Martin, Beverly Hills, Panama, Brésil, Paris, Milan, Principauté de Monaco, Genève, Belgique, Allemagne, Luxembourg, Espagne, Autriche, Londres, Fédération de Russie, Aspen, Maui, SoHo, Israël , La Jolla, Macao, Dubaï, Inde, Qatar, Arabie Saoudite, Beijing, Shanghai, Hong Kong, Tokyo et Tapei.*

__Naissance des Beaux-Arts IA — Québec.IA présente un nouveau mouvement artistique.__

<p align="center">
![Le parfum de l'IA (parfums) — Signé: Montreal.IA](../images/26eb011ai-v0.jpg "Le parfum de l'IA (parfums) — Signé: Montreal.IA")
</p>

> "**_Les artistes qui créeront avec l'IA ne suivront pas les tendances, ils les détermineront._**" — Les Beaux-Arts de Québec.IA

__Un mélange d'art, de culture et de science dans l'esprit de Léonard de Vinci.__

Ouvrant la porte à un nouveau mouvement artistique au 21 ème siècle, __les Beaux-Arts de Québec.IA__ suscite déjà un émoi parmi les plus grands collectionneurs d'art ainsi que parmi les personnalités les plus brillantes, les plus influentes et les plus iconoclastes du monde.

À la Renaissance, le pape __Jules II__ a commandité le peintre __Michel-Ange__, afin que celui-ci réalise le plafond de la __chapelle Sixtine__ au Vatican. Aujourd'hui, vous pouvez commander, de la même façon,  une œuvre d'art IA à la __Maison des Beaux-Arts de Québec.IA__.

Captivant un public  averti, __les Beaux-Arts de Québec.IA__ reflète une diversité esthétique, une richesse conceptuelle et le respect de la créativité la plus pure, exprimée par une machine et considérée comme la plus élevée dans la hiérarchie des genres. Nous préparons une campagne de relations publiques dans le monde entier avec la participation __à des émissions télévisées__ et avec la confection d'un __documentaire spécialisé__.

## Un nouveau jour est arrivé dans monde artistique

Le 25 octobre 2018, __l'histoire du marché de l'art__ de l'IA a été chamboulée. La première œuvre d'art en intelligence artificielle a été vendue aux enchères de Christie’s  et a bouleversé les attentes en atteignant 432 500 dollars.

![Edmond de Belamy, from La Famille de Belamy](../images/Edmond_de_Belamy_from_La_Famille_de_Belamy.png "Edmond de Belamy, from La Famille de Belamy")

### Références

- [The first AI artwork to be sold in a major auction achieves $432,500 after a bidding battle on the phones and via ChristiesLive](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee) — Christie's
- [A sign of things to come? AI-produced artwork sells for $433K, smashing expectations](https://edition.cnn.com/style/article/obvious-ai-art-christies-auction-smart-creativity/index.html) — Allyssia Alleyne, CNN
- [Eerie AI-generated portrait fetches $432,500 at auction](https://techcrunch.com/2018/10/26/eerie-ai-generated-portrait-fetches-432500-at-auction/) — Devin Coldewey, TechCrunch

> "**_Un porte-parole de Christie’s nous a parlé de l’excitation du marché face à ce changement important: "Nous pouvons confirmer qu'il y avait cinq soumissionnaires différents de toutes les régions du monde qui étaient en concurrence pour le lot à ce prix élevé, ce qui semble être un bon indice de l'intérêt des collectionneurs et du potentiel de marché futur pour l'art de l'intelligence artificielle en général..."_**" — Adam Heardman, MutualArt

## La Maison des Beaux-Arts de Québec.IA

__Histoire des Beaux-arts de l'IA: la construction d'un héritage__

__*La Maison des Beaux-Arts de Québec.IA*__ est en avance sur une tendance qui aura un impact profond sur l’industrie internationale de la mode, des beaux-arts et de la joaillerie, qui est un marché d’une valeur de 350 milliards de dollars par an ( 🌐 http://www.billionaire.tv/TheGazette.pdf ).

__Un renouveau des grands idéaux de la Renaissance.__ | Les agents d’intelligence artificielle de la __*Maison des Beaux-Arts de  Québec.IA*__ se bonifient par leurs enseignements acquis grâce à leurs expériences pour concevoir des œuvres d’art et une vision surhumaines! Nos créations sont des purs objets de désir évoquant les contes de fées et les rêves enchantés et traduisent un sentiment d'exclusivité: *une poésie fascinante, originale et vibrante de l'IA*.

![Dévoilement d'un monde majestueux de secrets cachés ...](../images/h355ai1440.jpg "Dévoilement d'un monde majestueux de secrets cachés ...")

Exaltant __*l'apprentissage en profondeur*__, __*l'apprentissage par renforcement*__, __*les réseaux antagonistes génératifs*__, __*le méta-apprentissage*__ et __*l'auto-apprentissage*__ à une échelle véritablement mondiale et pour déployer avec passion et avec une inhabituelle élégance une nouvelle approche, __*la Maison des Beaux-Arts de  Québec. IA*__ propose  des créations surhumaines et des designs révolutionnaires générés par l'IA, qui sont uniques en leur genre, dévoilant un monde majestueux de secrets cachés:

__❖ Le parfum de l'IA (parfums)__
Une ligne aussi enchanteresse que les muses qu’elle inspire.

__❖ Haute-Joaillerie IA Multi-Mondes ( 💎 )__
*Une collection qui est sur le point de redéfinir l'industrie du diamant du XXIème siècle.*
__La Maison des Beaux-Arts de Québec.IA__ est pionnière dans les nouvelles coupes de  diamants et atteint un sommet sans précédent en matière de brillance, de scintillement et de dispersion pour les fashionistas qui définiront les tendances de la haute-joaillerie de notre époque.

__❖ Oeuvres d'art (signées: Québec.IA)__
Des oeuvres originales numérotées et signées, certificat d'authenticité compris.

![Dévoilement d'un monde majestueux de secrets cachés ...](../images/AIDiamond.mp4 "Dévoilement d'un monde majestueux de secrets cachés ...")

Une odyssée au coeur univers parallèles cosmologiques, divins et mythologiques rendue possible par l'IA. 

### Une histoire légendaire: la source d'un héritage exceptionnel

__Le secrétariat général du Conseil exécutif des Beaux-Arts de Québec.IA__

Catalyseur professionnel et expérimenté dans les domaines de la recherche innovante, de l’ingénierie financière et du luxe international, __le président-fondateur de Québec.IA,__ Vincent Boucher, a reçu le 15 octobre 2009, le prestigieux certificat __Record du monde *Guinness*__ pour sa Tourmaline Paraiba taillée la plus importante au monde.

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf](../images/GuinnessWorldRecordsCertificate.jpg "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

__Un travail d'innovation intellectuelle, esthétique et technique__ | La clairvoyance stratégique de Vincent Boucher et sa capacité à mener l’un des projets les plus ambitieux de l’Histoire lui ont permis de se positionner à la fine pointe de son domaine et de se forger une réputation bien méritée à l’échelle mondiale.

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.](../images/TheGazetteBusinessFrontPage.tif "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.]")](http://www.billionaire.tv/TheGazette.pdf)

> "**_L'homme d'affaires  (Vincent Boucher) acquiert la pierre la plus rare au monde."_**" — Mike King, The Gazette

[![Guinness World Records™ | It's a gem of a start for Billionaire](../images/mosaic.tif "Guinness World Records™ | It's a gem of a start for Billionaire")](http://www.billionaire.tv/TheGazette.pdf)

Magnifiant les créations les plus pures et les plus belles, en proposant un enseignement et des recherches révélant des aspects uniques d'un point de vue critique, intellectuel et historique et en ouvrant les portes à un nouveau mouvement artistique, __*la Maison des Beaux-Arts de Québec.IA*__ alimente la passion qui anime les artistes de l'IA les plus performants du moment.

## Définir le genre des Beaux-Arts en IA

__Un sentiment de mystère… et une compréhension profonde du monde, des gens et de la nature humaine.__

![Principia of The Grand Design: Québec.AI Fine Arts believes in seamlessly seing relationships that matter](../images/ExTradingUniverseTwoMay18HD1080-v0.mp4 "Principia of The Grand Design: Québec.AI Fine Arts believes in seamlessly seing relationships that matter")

> "**_Pour identifier les œuvres véritablement novatrices, nous ferions mieux de cesser de nous questionner à savoir où se situe la frontière entre le travail de l'artiste et l'utilisation des outils de l'IA, et de plutôt commencer à nous demander si des artistes humains utilisent l'IA pour approfondir leurs concepts et leur esthétisme plus que les chercheurs ou codeurs._**" — Tim Schneider et Naomi Rea, artnet, 25 septembre 2018

__Apprentissage en profondeur +  Apprentissage par renforcement + Réseaux antagonistes génératifs + Méta-apprentissage + Auto-apprentissage__

### Références

- [Data Science, Machine Learning and Artificial Intelligence for Art](https://towardsdatascience.com/data-science-machine-learning-and-artificial-intelligence-for-art-1ac48c4fad41) — Vishal Kumar
- [Scaling the Mission: The Met Collection API (406,000 images of over 205,000 CC0 objects)](https://www.metmuseum.org/blogs/now-at-the-met/2018/met-collection-api) — Loic Tallon, Chief Digital Officer
- [What do 50 million drawings look like?](https://quickdraw.withgoogle.com/data) — Google
- [Neural scene rendering: Transfer learning to render a fruit still life from photos](https://docs.google.com/presentation/d/182KZT1Qg1rY8qnroDytn-4z5ODFjNSYkfNlwbDJAI-o/edit#slide=id.g35f391192_00) — Brett Göhre
- GAN Lab: Play with Generative Adversarial Networks (GANs) in your browser! [Web](https://poloclub.github.io/ganlab/) | [Paper](https://minsuk.com/research/papers/kahng-ganlab-vast2018.pdf) — Minsuk Kahng, Nikhil Thorat, Polo Chau, Fernanda Viégas, and Martin Wattenberg
- [Generating Memoji from Photos](https://patniemeyer.github.io/2018/10/29/generating-memoji-from-photos.html) — Pat Niemeyer
- [Playing a game of GANstruction](https://thegradient.pub/playing-a-game-of-ganstruction/) — Helena Sarin
- Large Scale GAN Training for High Fidelity Natural Image Synthesis [Paper](https://arxiv.org/abs/1809.11096) | [TF Hub](https://tfhub.dev/s?q=biggan) | [Colab](https://colab.research.google.com/github/tensorflow/hub/blob/master/examples/colab/biggan_generation_with_tf_hub.ipynb) — Andrew Brock, Jeff Donahue, Karen Simonyan
- [TL-GAN: transparent latent-space GAN](https://github.com/SummitKwan/transparent_latent_gan) — SummitKwan
- [TensorFlow-GAN (TFGAN)](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/contrib/gan) — Joel Shor, Sergio Guadarrama
- [Progressive GANs | Notebook with smooth interpolations through z-space](https://github.com/genekogan/progressive_growing_of_gans/blob/master/generate.ipynb) — Gene Kogan
- Self-Attention GAN [Paper](https://arxiv.org/abs/1805.08318) | [Tensorflow implementation](https://github.com/brain-research/self-attention-gan) — Han Zhang, Ian Goodfellow, Dimitris Metaxas, Augustus Odena
- [Discriminator Rejection Sampling](https://arxiv.org/abs/1810.06758) — Samaneh Azadi, Catherine Olsson, Trevor Darrell, Ian Goodfellow, Augustus Odena
- [Tensorpack | Generative Adversarial Networks](https://github.com/tensorpack/tensorpack/tree/master/examples/GAN) — Tensorpack
- [Ngx | Neural network based visual generator and mixer](https://github.com/keijiro/Ngx) — Keijiro Takahashi
- [Magenta Studio (beta)](https://magenta.tensorflow.org/studio) — Google AI
- [Differentiable Monte Carlo Ray Tracing through Edge Sampling](https://people.csail.mit.edu/tzumao/diffrt/) — Tzu-Mao Li, Miika Aittala, Frédo Durand, Jaakko Lehtinen
- [A Few Unusual Autoencoders](https://colinraffel.com/talks/vector2018few.pdf) — Colin Raffel
- [Deep Variational Reinforcement Learning for POMDPs](https://arxiv.org/abs/1806.02426) — Maximilian Igl, Luisa Zintgraf, Tuan Anh Le, Frank Wood, Shimon Whiteson
- [Learning Dexterity](https://blog.openai.com/learning-dexterity/) — OpenAI
- [Robots that Learn](https://blog.openai.com/robots-that-learn/) — OpenAI
- [(Self-Play) | OpenAI Five](https://blog.openai.com/openai-five/) — OpenAI
- [TFHub state-of-the-art AutoAugment Modules](https://tfhub.dev/s) — TensorFlow
- [Creatability: a new collection of experiments exploring ways to make creative tools more accessible](https://g.co/creatability) — Experiments with Google
- [Evolved Virtual Creatures, Evolution Simulation, 1994](https://youtu.be/JBgG_VSP7f8) — Karl Sims
- Reinforcement Learning for Improving Agent Design: What happens when we let an agent learn a better body design together with learning its task? [Article](https://designrl.github.io/) | [Paper](https://arxiv.org/abs/1810.03779 ) — David Ha

> "**_La technologie de création artistique de notre époque sera l'IA._**" — Rama Allen

## #AI4Artists : Révélons un monde de secrets cachés

__Confectionner des création légendaires: un cours de 75 minutes bien conçu pour les artistes__

[![Pioneering Legendary Creations : 75 Minutes Tutorial](../images/AI4ArtistsP1.jpg "#AI4Artists : Unveilling a World of Hidden Secrets")](http://www.montreal.ai/AI4Artists.pdf)
<a href="https://www.eventbrite.ca/e/montrealai-academy-artificial-intelligence-for-artists-ai4artists-tickets-52966101034?ref=ebtn" target="_blank"><img src="https://www.eventbrite.ca/custombutton?eid=52966101034" alt="Eventbrite - Montréal.AI Academy: Artificial Intelligence for Artists #AI4Artists" /></a>

__Vers qui vous  tourneriez-vous si vous souhaitiez apprendre le meilleur de l'IA pour les artistes?__

__Le Secrétariat général de QUÉBEC.IA__ présente, en toute légitimité par  ses connaissance aiguisées, toutes les facettes de l’IA pour les artistes: "__*#AI4Artists: premier survol mondial de l’IA pour les artistes*__".

__PUISSANT ET UTILE.__ Ce cours pratique est conçu pour offrir à tous l’état d’esprit, les compétences et les outils nécessaires pour percevoir l’intelligence artificielle d’un nouveau point de vue stimulant:

— Des découvertes et des connaissances scientifiques de pointe;
— Les meilleurs codes et implémentations "open source";
— L’impulsion qui anime l’intelligence artificielle d’aujourd’hui.

Conçu pour les artistes, [__*#AI4Artists*__](http://www.montreal.ai/AI4Artists.pdf) est créé pour inspirer les artistes qui, avec IA, façonneront le 21ème siècle.

## Une célébration vraiment spéciale qui marquera l'histoire!

Pour André Breton, le père du surréalisme, le but de l'art est l'unification du réel et de l'imaginaire. __Les Beaux-Arts de Québec.IA__ réalise le rêve de Breton. Une célébration vraiment spéciale dans le monde des beaux-arts, de la mode et de la haute-joaillerie et qui fera certainement l'histoire!

*Nous recherchons des ambassadeurs et des partenaires.*

✉️ __Courriel__ : info@quebec.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.quebec.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Québec.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IntelligenceArtificielle__ #__IntelligenceArtificielleQuebec__ #__QuebecIA__
