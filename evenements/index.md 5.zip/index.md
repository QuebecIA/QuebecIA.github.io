---
title: QUÉBEC.IA | Intelligence artificielle Québec
---
## **ÉVÉNEMENTS DE QUÉBEC.IA**

### **Dîner de presse | Concert | Vente aux enchères | Gala de bienfaisance**

![Les événements de Québec.IA](../images/QuebecIAv6WhatIsAI1440x1440.jpg "Les événements de Québec.IA")

## **❖ Série de débats sur l'IA de MONTREAL.IA**

### **DÉBAT AI 2: 23 décembre 2020, 16 h 00 - 19 h 00 HNE | "Faire avancer l'IA: une approche interdisciplinaire"**

[![Série de débats sur l'IA de MONTREAL.IA | AI DEBATE 2 : MARQUEZ VOTRE CALENDRIER — 23 décembre 2020, 16 h 00 - 19 h 00 HNE](../images/aidebate2mosaic1440x720v8.jpg "Série de débats sur l'IA de MONTREAL.IA | AI DEBATE 2 : MARQUEZ VOTRE CALENDRIER — 23 décembre 2020, 16 h 00 - 19 h 00 HNE")](https://aidebate.eventbrite.ca)

#### **Programme**

**Panel 1**: _Architecture et défis_

**Panel 2**: _Regards sur les neurosciences et la psychologie_

**Panel 3**: _Vers une IA sur laquelle nous pouvons faire confiance_

#### **Conférenciers confirmés**

- _**Ryan Calo**_;
- _**Yejin Choi**_;
- _**Daniel Kahneman**_;
- _**Celeste Kidd**_;
- _**Christof Koch**_;
- _**Luis Lamb**_;
- _**Fei-Fei Li**_;
- _**Adam Marblestone**_;
- _**Margaret Mitchell**_;
- _**Robert Osazuwa Ness**_;
- _**Judea Pearl**_;
- _**Francesca Rossi**_;
- _**Ken Stanley**_;
- _**Rich Sutton**_;
- _**Doris Tsao**_; et
- _**Barbara Tversky**_.

Modérateur et co-organisateur (avec _Vincent Boucher_): _**Gary Marcus**_

Faire partie de la conversation sur les réseaux sociaux: #**AIDebate2**

**Site Web AI Debate 2:** https://montrealartificialintelligence.com/aidebate2/

### **Billets et réservation de groupe**

Réservation: https://aidebate.eventbrite.ca

__Date et heure :__ mercredi 23 décembre 2020 | 16:00 à 19:00 (heure de Montréal)

<div id="eventbrite-widget-container-89401898485"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '89401898485',
        iframeContainerId: 'eventbrite-widget-container-89401898485',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

### **AI DEBATE 1 : Yoshua Bengio | Gary Marcus**

[![Événements de classe mondiale de Montréal.IA — AI DEBATE 1 : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "Événements de classe mondiale de Montréal.IA — AI DEBATE 1 : Yoshua Bengio | Gary Marcus")](https://montrealartificialintelligence.com/aidebate/)

À l’agora de Mila, à Montréal, le lundi 23 décembre 2019, de 18h30 à 20h30 (heure de l'Est), Gary Marcus et Yoshua Bengio ont débattu sur la meilleure voie à suivre pour l'IA. ZDNet a décrit l'événement organisé par MONTRÉAL.IA comme un [“événement historique”](https://www.zdnet.com/article/devils-in-the-details-in-bengio-marcus-ai-debate/). 5,225 billets ont été réservés pour l'événement en direct. [Compte-rendu du débat sur l'IA](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/).

Des **diapositives, vidéos, lectures** et autres sont disponibles sur la [page web](https://montrealartificialintelligence.com/aidebate/) du débat de **MONTRÉAL.IA**.

**MONTRÉAL.IA** est reconnaissante envers [Gary Marcus](http://garymarcus.com), [Yoshua Bengio](https://mila.quebec/en/yoshua-bengio/), [Mila - Institut Québécois d'Intelligence Artificielle](https://mila.quebec/) et envers l'[écosystème collaboratif de Montréal en matière d'IA](https://www.facebook.com/groups/MontrealAI/). Un remerciement spécial à [Sasha Lu](https://sashaluccioni.com).

[![100 pays et 1000 villes](../images/attendeescity.jpeg "100 pays et 1000 villes")](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/)

***

*(Cet événement est offert en ligne à une clientèle internationale en anglais)*
## __❖ Deep Reinforcement Learning with OpenAI Gym 101__

**Samedi, 13 février 2021, 10:00 AM – 11:30 AM** (heure de Montréal), le secrétariat général de __MONTRÉAL.IA__ présentera, avec autorité: "__*Deep Reinforcement Learning with OpenAI Gym 101*__" (en anglais).

<a href="https://reinforcementlearning101.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Acheter des billets sur Eventbrite</a>

[![Événement en ligne: 'Deep Reinforcement Learning with OpenAI Gym 101'](../images/RL101Webinarv19.jpg "Événement en ligne: 'Deep Reinforcement Learning with OpenAI Gym 101'")](https://reinforcementlearning101.eventbrite.ca)

<div id="eventbrite-widget-container-117727240345"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117727240345',
        iframeContainerId: 'eventbrite-widget-container-117727240345',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Langue:__ La présentation sera en __anglais__. *Le matériel de référence sera dans sa langue originale*.

> "**_L'intelligence est la partie informatique de la capacité à prédire et à contrôler un flux d'expériences._**" — Rich Sutton

__Lieu: L'événement a lieu en ligne.__ Il s'agit d'un webinaire en direct avec interaction avec et entre les étudiants. Les participants recevront des instructions sur la façon d'accéder à la diffusion en direct à *9:45 AM (heure de Montréal) samedi le 13 février 2021*.

***

## **❖ SYMPOSIUM QUÉBEC IA**

### _Stimuler l’activité économique, la recherche et l’innovation en IA au Québec_

[![SYMPOSIUM QUÉBEC IA — Stimuler l’activité économique, la recherche et l’innovation en IA au Québec](../images/quebecaisymposium.png "SYMPOSIUM QUÉBEC IA — Stimuler l’activité économique, la recherche et l’innovation en IA au Québec")](https://quebecaisymposium.eventbrite.ca)

Le **SYMPOSIUM QUÉBEC IA**, administré par [MONTRÉAL.IA](http://www.montreal.ai) et [QUÉBEC.IA](http://www.quebec.ai), est un événement visant à stimuler l'activité économique, la recherche et l'innovation en intelligence artificielle au Québec et ainsi contribuer à la compétitivité et au rayonnement du Québec sur les plans national et international.

### Billets et réservation de groupe

__Réservation de groupe:__ secretariat@montreal.ai

__Billets:__ https://quebecaisymposium.eventbrite.ca

__Date et heure:__ __Jeu. 10 juin 2021 | De 9 h 30 à 20 h 30 HAE (heure de Montréal)__.
__Location: Détails à annoncer__.

__Site web:__ http://quebecaisymposium.com.

***

## **❖ Célébration des chefs de file de l'industrie de l'IA**

### _Hommage aux chefs de file primés de l'industrie de l'IA & des sommités_

***

## **❖ Dîner de presse de QUÉBEC.IA**

### _Hommage au journalisme en IA méritant_

***

## **❖ Vente aux enchères des beaux-arts de QUÉBEC.IA**

### _Dévoilement d'un monde de secrets cachés..._

![La vente aux enchères des beaux-arts de QUÉBEC.IA : un monde de secrets cachés à dévoiler...](../images/AITrillion1440.jpg "La vente aux enchères des beaux-arts de QUÉBEC.IA : un monde de secrets cachés à dévoiler...")

Le 25 octobre 2018, [la première œuvre d'art en intelligence artificielle jamais vendue par la maison de ventes aux enchères Christie's a bouleversé les attentes, atteignant 432 500 $](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Aujourd'hui, la _Maison des Beaux-Arts de Québec.IA_ présente : _La vente aux enchères des Beaux-Arts de Québec.IA_, la **première vente aux enchères internationale consacrée à la quintessence des Beaux-Arts de l'IA**.

> "**_Les artistes qui créent avec AI ne suivront pas les tendances, ils les définiront._**" — Québec.IA

Nous nous préparons pour la première vente aux enchères.

Les plus grands collectionneurs d'œuvres d'art pourront faire des offres à l'échelle internationale.

***

## **❖ Salon de QUÉBEC.IA**

### _Rassemblement de gens sous le toit d'un hôte inspirant_

![Le salon QUÉBEC.IA](../images/quebeciasalonv0.jpg "Le salon QUÉBEC.IA s’inscrit dans la plus pure tradition des salons littéraires et philosophiques français du XV IIIème siècle.")

Le salon QUÉBEC.IA s’inscrit dans la plus pure tradition des salons littéraires et philosophiques français du XV IIIème siècle. Débats et joutes d’idées en compagnie d’invités s’étant illustrés.

***

*(Cet événement est offert en ligne à une clientèle internationale en anglais)*
## **❖ Chief AI Officers : C-level AI**

### _Executive Education‎_

__*Chief AI Officers : C-level AI*__ harnesses the fundamentals of artificial intelligence on a truly global scale and put them to strategically leverage enterprises, governments and institutions with precision engineering.

[![Chief AI Officers : C-level AI | Executive Education‎](../images/ExecutiveEducation‎.jpg "Chief AI Officers : C-level AI | Executive Education‎")](https://chiefaiofficers.eventbrite.ca)
<a href="https://chiefaiofficers.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Chief AI Officers : C-level AI | Ticket</a>
> "**_In a moment of technological disruption, leadership matters._**" — Andrew Ng

__Success is about actively shaping the game that matters to you.__ This well-crafted C-level professional keynote pioneers a highly impactful understanding of [_transformative artificial intelligence_](https://www.openphilanthropy.org/blog/some-background-our-views-regarding-advanced-artificial-intelligence#Sec1) strategies, at boardroom level, bringing to life new perspectives for state, national, and international organizations.

### Participant Profile
{% pullquote [CSS class] %}
"**_We want to see more life-long learning opportunities, across the board matrix interoperability and the development of Chief AI Officers who possess the knowledges, the skills and the competencies to orchestrate impactful breakthroughs and tangible economic growth for Fortune 500, governments and interagency partners in full compliance with our masterplan : The Montréal AI-First Conglomerate Overarching Program._**" — Vincent Boucher, B. Sc. Physics, M. A. Policy Analysis and M. Sc. Aerospace Engineering (Space Technology), Founding Chairman at Montréal.AI
{% endpullquote %}
__*Chief AI Officers : C-level AI*__  is designed for the : 

- Board Members;
- Captains of Industry;
- Chancellors;
- Chief Executive Officers;
- Commanders;
- Excellences;
- Global Chairs
- High-Potential Executives;
- Iconic Tech Entrepreneurs;
- Luminaries;
- Managing Directors;
- Moguls;
- Philanthropists;
- Presidents;
- Scholars;
- Successful Entrepreneurs and Financiers; and
- Visionary Founders

... who wish to strategically incorporate the "*Emerging Rules of the AI-First Era*" into enterprises, governments and institutions, at boardroom level, in order to unleash the power of artificial intelligence on a truly global scale.

> "**_Breakthrough in machine learning would be worth 10 Microsofts._**" — Bill Gates

<div id="eventbrite-widget-container-126693606989"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '126693606989',
        iframeContainerId: 'eventbrite-widget-container-126693606989',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Location: This is an online event.__

***

## **❖ Intelligence artificielle 101: Webinaire**

### _Instituer une compréhension percutante de l'IA_

Englobant toutes les facettes de l'IA, le __Secrétariat général de MONTRÉAL.IA__ présente, avec autorité: "__*Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public*__".

__Lieu : Il s'agit d'un événement en ligne.__

<p style="text-align: center;"><a href="https://intelligenceartificielle.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Intelligence Artificielle 101: Webinaire | Date et heure: samedi, 26 septembre 2020, 10:00 AM - 11:30 AM EDT</a></p>

[![Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public](../images/IA101Webinairev0.jpg "Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public")](https://intelligenceartificielle.eventbrite.ca)

__L'IA ouvre un monde de nouvelles possibilités.__ Ce cours IA 101 explore les bases de l'intelligence artificielle dans le but de transmettre aux participant(e)s de puissants outils d'IA pour *apprendre*, *déployer* et *faire évoluer* l'IA.

> "**_(L'IA) comptera parmi nos plus grandes réalisations technologiques, et tout le monde mérite de jouer un rôle dans son élaboration._**" — Fei-Fei Li

<div id="eventbrite-widget-container-110337374056"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '110337374056',
        iframeContainerId: 'eventbrite-widget-container-110337374056',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Billets:__ https://intelligenceartificielle.eventbrite.ca

__Réservation de groupe:__ secretariat@montreal.ai

__Date et heure:__ Samedi, 26 septembre 2020, 10:00 AM - 11:30 AM EDT

__Langue:__ La présentation sera en __français__. *Le matériel de référence sera dans sa langue originale*.

__Lieu: L'événement a lieu en ligne.__ Il s'agit d'un webinaire en direct avec interaction avec et entre les étudiants.

** Le contenu de ce cours est destiné à votre usage personnel et ne doit pas être partagé ou diffusé. __En cas de force majeure, l'événement sera reporté à une date ultérieure.__

***

*(Cet événement est offert en ligne à une clientèle internationale en anglais)*
## **❖ Artificial Intelligence 101 | International Webinar**

### _Pioneering an Impactful Understanding of AI_

For the newcomers to artificial intelligence, the __General Secretariat of MONTREAL.AI__ introduces, with authority: "__*Artificial Intelligence 101*__: *The First World-Class Overview of AI for the General Public*".

__Location: This is an online event.__

[![ONLINE EVENT : ARTIFICIAL INTELLIGENCE 101](../images/academy1920cover_v0.jpg "ARTIFICIAL INTELLIGENCE 101")](https://artificialintelligence101.eventbrite.ca)

__AI opens up a world of new possibilities.__ This __Artificial Intelligence 101__ harnesses the fundamentals of AI for the purpose of providing participants with powerful AI tools to *__learn__*, *__deploy__* and *__scale AI__*.

> "**_(AI) will rank among our greatest technological achievements, and everyone deserves to play a role in shaping it._**" — Fei-Fei Li

__Program overview and tickets:__ https://artificialintelligence101.eventbrite.ca

<div id="eventbrite-widget-container-117895790483"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117895790483',
        iframeContainerId: 'eventbrite-widget-container-117895790483',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Language:__ Tutorial (webinar) given in __English__.
__Date And Time:__ Sat, March 13, 2021 | 10:00 AM – 11:30 AM EST
__Location: This is an online event.__ This is a live streamed webinar with interaction with and among students. *Attendees will receive instructions on how to access at 9:45 AM (EST) on Sat, Mar 13, 2021*.

** The content of the webinar is for your personal use and should not be shared or/and distributed. __In case of force majeure, the event will be postponed to a later date.__

***

## **❖ Conversation au coin du feu de QUÉBEC.IA**

***

## **❖ MONTREAL.AI MIXER _(RÉUNION de MONTRÉAL.IA)_**

### _Orchestrer des synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA de Montréal_

[![MONTREAL.AI MIXER — Orchestrer les synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA à Montréal.](../images/MontrealAIMixerv2.jpg "MONTREAL.AI MIXER — Orchestrer les synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA à Montréal.")](https://aimixer.eventbrite.ca)

### Billets et réservation de groupe

__Réservation de groupe :__ secretariat@montreal.ai

__Billets :__ https://aimixer.eventbrite.ca

__Date et heure :__ __Jeudi, 10 juin 2021 | 17:30 à 19:30 (heure de Montréal)__
__Lieu : Détails à annoncer__

***

## **❖ Dîner des ambassadeurs de QUÉBEC.IA**

***

## **❖ Orchestre de QUÉBEC.IA**

### _Des symphonies pionnières surhumaines_

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ Gala du Mérite philanthropique de QUÉBEC.IA**

> "**_C'est le printemps pour l'IA, et nous prévoyons un long été._**" — Bill Braun, CIO de Chevron

✉️ __Courriel__ : info@quebec.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.quebec.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Québec.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif exclusivement*

#__IntelligenceArtificielleQuebec__ #__QuebecIA__
