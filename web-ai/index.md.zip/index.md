---
title: WebAI — Artificial Intelligence for the Web
---
## Deploying AI in the Browser

Running machine learning programs entirely client-side in the browser unlocks new opportunities, like interactive ML! From a user’s perspective, there’s no need to install any libraries or drivers : Just open a webpage, and your program is ready to run! On a mobile device, the model can take advantage of sensor data (i.e.: gyroscope or accelerometer). Finally, all data stays on the client, making TensorFlow.js useful for low-latency inference, as well as for privacy preserving applications.

![Montréal.AI Web — Artificial Intelligence for the Web](../images/ai_web.jpg "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

## Low-Latency Inference and Privacy Preserving Applications

![An overview of TensorFlow.js](../images/TensorFlow_js_API.png "An overview of TensorFlow.js")

The ...

![TensorBoard: Visualizing Learning](../images/algo_tensorboard_log.png "TensorBoard: Visualizing Learning")

<p data-height="265" data-theme-id="dark" data-slug-hash="gzjgEP" data-default-tab="js,result" data-user="teropa" data-embed-version="2" data-pen-title="Robot Neil's Bubble Bath" class="codepen">See the Pen <a href="https://codepen.io/teropa/pen/gzjgEP/">Robot Neil's Bubble Bath</a> by Tero Parviainen (<a href="https://codepen.io/teropa">@teropa</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
